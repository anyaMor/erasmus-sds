﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace SDS.Models
{
    public class ErasmusContext: DbContext
    {
        public DbSet<Student> Students { get; set; }
        public DbSet<Instituition> Instituitions { get; set; }
        public DbSet<Course> Courses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=erasmus.db");
        }

    }
}
