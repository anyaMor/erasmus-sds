﻿using Microsoft.EntityFrameworkCore;

namespace SDS.Models
{
    public class ErasmusContext: DbContext
    {
        public DbSet<Instituition> Instituitions { get; set; }
        public DbSet<Course> Courses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=erasmus.db");
        }

    }
}
