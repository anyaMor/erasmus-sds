﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SDS.Models
{
    public class Course
    {
        public int ID { get; set; }

        public string name { get; set; }
        public string ect { get; set; }
        public string semesterType{ get; set; }
        public string code { get; set; }

    }
}
