﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SDS.Models
{
    public class LearningAgreement
    {
        public int ID { get; set; }

        public string seed { get; set; }

        public string name { get; set; }
    }
}
