﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SDS.Models
{
    public class Student
    {
        public int ID { get; set; }

        public string firstName { get; set; }
        public string lastName { get; set; }
        public string birth { get; set; }
        public string nationality { get; set; }
        public string sex { get; set; }
        public string studyCicle { get; set; }
        public string fieldEdu { get; set; }
    }
}
