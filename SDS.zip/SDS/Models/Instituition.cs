﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SDS.Models
{
    public class Instituition
    {
        public int ID { get; set; }

        public string name { get; set; }
        public string code { get; set; }
        public string address { get; set; }
        public string country { get; set; }
        public string contact { get; set; }

        public ICollection<Student> students { get; set; }
        public ICollection<Course> courses { get; set; }
    }
}
