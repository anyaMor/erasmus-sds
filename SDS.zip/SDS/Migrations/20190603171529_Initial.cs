﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SDS.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Courses_Courses_CourseID",
                table: "Courses");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.RenameColumn(
                name: "CourseID",
                table: "Courses",
                newName: "InstituitionID");

            migrationBuilder.RenameIndex(
                name: "IX_Courses_CourseID",
                table: "Courses",
                newName: "IX_Courses_InstituitionID");

            migrationBuilder.AddColumn<int>(
                name: "CommentID",
                table: "Courses",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Comments",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    nameUser = table.Column<string>(nullable: true),
                    title = table.Column<string>(nullable: true),
                    text = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Comments", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "LearningAgreements",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    seed = table.Column<string>(nullable: true),
                    name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LearningAgreements", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Courses_CommentID",
                table: "Courses",
                column: "CommentID");

            migrationBuilder.AddForeignKey(
                name: "FK_Courses_Comments_CommentID",
                table: "Courses",
                column: "CommentID",
                principalTable: "Comments",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Courses_Instituitions_InstituitionID",
                table: "Courses",
                column: "InstituitionID",
                principalTable: "Instituitions",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Courses_Comments_CommentID",
                table: "Courses");

            migrationBuilder.DropForeignKey(
                name: "FK_Courses_Instituitions_InstituitionID",
                table: "Courses");

            migrationBuilder.DropTable(
                name: "Comments");

            migrationBuilder.DropTable(
                name: "LearningAgreements");

            migrationBuilder.DropIndex(
                name: "IX_Courses_CommentID",
                table: "Courses");

            migrationBuilder.DropColumn(
                name: "CommentID",
                table: "Courses");

            migrationBuilder.RenameColumn(
                name: "InstituitionID",
                table: "Courses",
                newName: "CourseID");

            migrationBuilder.RenameIndex(
                name: "IX_Courses_InstituitionID",
                table: "Courses",
                newName: "IX_Courses_CourseID");

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    InstituitionID = table.Column<int>(nullable: true),
                    birth = table.Column<string>(nullable: true),
                    fieldEdu = table.Column<string>(nullable: true),
                    firstName = table.Column<string>(nullable: true),
                    lastName = table.Column<string>(nullable: true),
                    nationality = table.Column<string>(nullable: true),
                    sex = table.Column<string>(nullable: true),
                    studyCicle = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Students_Instituitions_InstituitionID",
                        column: x => x.InstituitionID,
                        principalTable: "Instituitions",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Students_InstituitionID",
                table: "Students",
                column: "InstituitionID");

            migrationBuilder.AddForeignKey(
                name: "FK_Courses_Courses_CourseID",
                table: "Courses",
                column: "CourseID",
                principalTable: "Courses",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
