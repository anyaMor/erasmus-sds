﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SDS.Models;

namespace SDS.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        

        public IActionResult Erasmus1(string operation)
        {
            return View();
        }

        public IActionResult Erasmus2(string operation)
        {
            try
            {
                string eng = "";
                string result = "";
                string receivedInfo = "";
                string webLink = "";
                List<Course> totalCourses = new List<Course>();


                if (operation.Equals("Continue"))
                {
                    result = Request.Form["fname"] + "????" + Request.Form["lname"] + "????" + Request.Form["birth"] + "????" + Request.Form["nat"] + "????"
                   + Request.Form["sex"] + "????" + Request.Form["sc"] + "????" + Request.Form["edu"] + "????" + Request.Form["sin"] + "????"
                   + Request.Form["sif"] + "????"
                   + Request.Form["sic"] + "????" + Request.Form["sia"] + "????" + Request.Form["sicountry"] + "????" + Request.Form["sicont"] + "????"
                   + Request.Form["rif"] + "????" + Request.Form["dd"] + "????" + Request.Form["da"];

                }
                else if(operation != null && operation.Contains("Remove Course"))
                {
                    result = Request.Form["Result"];
                    string numberCourse = operation.Split("Remove Course ")[1];
                    receivedInfo = Request.Form["ReceivedInfo"];

                    var received = receivedInfo.Split("++++").ToList();

                    received.RemoveAt(Int32.Parse(numberCourse) - 1);

                    foreach (string r in received)
                    {
                        using (var db = new ErasmusContext())
                        {
                            var c = (
                            from Course in db.Courses
                            where Course.name.Equals(r)
                            select Course);

                            totalCourses.Add(c.First());
                        }
                    }
                    eng = Request.Form["english"];
                    webLink = Request.Form["webLink"];
                    receivedInfo = "";
                    foreach(string rec in received)
                    {
                        if (receivedInfo.Equals(""))
                        {
                            receivedInfo = rec;
                        }
                        else
                        {
                            receivedInfo = receivedInfo + "++++" + rec;
                        }
                    }
                }
                else
                {
                    result = Request.Form["Result"];
                    if(Request.Form["ReceivedInfo"].Equals(""))
                    {
                        receivedInfo = Request.Form["courses"];
                    }
                    else
                    {
                        receivedInfo = Request.Form["ReceivedInfo"] + "++++" + Request.Form["courses"];
                    }
                    

                    var received = receivedInfo.Split("++++");
                    foreach (string r in received)
                    {
                        using (var db = new ErasmusContext())
                        {
                            var c = (
                            from Course in db.Courses
                            where Course.name.Equals(r)
                            select Course);



                            totalCourses.Add(c.First());
                        }
                    }
                    

                    eng = Request.Form["english"];
                    webLink = Request.Form["webLink"];

                }
                ViewData["Result"] = result;
                ViewData["english"] = eng;
                ViewData["ReceivedInfo"] = receivedInfo;
                ViewBag.List = totalCourses;
                ViewData["webLink"] = webLink;


            }
            catch (Exception)
            {
                ViewData["Result"] = "";
            }

            return View();
        }
        public IActionResult Erasmus3(string operation)
        {
            try
            {
                bool check = false;

                string result = "";
                string namest = "";
                string emailst = "";
                string positionst = "";
                string nameR = "";
                string emailR = "";
                string positionR = "";
                string nameS = "";
                string emailS = "";
                string positionS = "";
                string nameC = "";
                string codeC = "";
                string semesterC = "";
                string ectsC = "";

                string receivedInfoCourses = "";
                string webLink2 = "";


                if (operation.Equals("Add Course"))
                {
                    check = true;
                    result = Request.Form["Result"];
                    namest = Request.Form["namest"];
                    emailst = Request.Form["emailst"];
                    positionst = Request.Form["positionst"];
                    nameR = Request.Form["nameR"];
                    emailR = Request.Form["emailR"];
                    positionR = Request.Form["positionR"];
                    nameS = Request.Form["nameS"];
                    emailS = Request.Form["emailS"];
                    positionS = Request.Form["positionS"];

                    receivedInfoCourses = Request.Form["receivedInfoCourses"];

                    webLink2 = Request.Form["webLink2"];



                }
                else if(operation.Equals("Submit Course"))
                {
                    result = Request.Form["Result"];
                    namest = Request.Form["namest"];
                    emailst = Request.Form["emailst"];
                    positionst = Request.Form["positionst"];
                    nameR = Request.Form["nameR"];
                    emailR = Request.Form["emailR"];
                    positionR = Request.Form["positionR"];
                    nameS = Request.Form["nameS"];
                    emailS = Request.Form["emailS"];
                    positionS = Request.Form["positionS"];
                    webLink2 = Request.Form["webLink2"];

                    nameC = Request.Form["nameC"];
                    semesterC = Request.Form["semesterC"];
                    codeC = Request.Form["codeC"];
                    ectsC = Request.Form["ectsC"];
                    if (Request.Form["receivedInfoCourses"].ToString().Equals(""))
                    {
                        receivedInfoCourses =  nameC + "$$" + semesterC + "$$" + codeC + "$$" + ectsC;
                    }
                    else
                    {
                        receivedInfoCourses = Request.Form["receivedInfoCourses"] + "###" + nameC + "$$" + semesterC + "$$" + codeC + "$$" + ectsC;
                    }
                }
                else if (operation != null && operation.Contains("Remove Course"))
                {
                    result = Request.Form["Result"];
                    string numberCourse = operation.Split("Remove Course ")[1];
                    receivedInfoCourses = Request.Form["ReceivedInfoCourses"];

                    var received = receivedInfoCourses.Split("###").ToList();

                    received.RemoveAt(Int32.Parse(numberCourse) - 1);

                    receivedInfoCourses = "";

                    foreach(string r in received)
                    {
                        if (receivedInfoCourses.Equals(""))
                        {
                            receivedInfoCourses = r;
                        }
                        else
                        {
                            receivedInfoCourses = receivedInfoCourses + "###" + r;
                        }
                    }

                    namest = Request.Form["namest"];
                    emailst = Request.Form["emailst"];
                    positionst = Request.Form["positionst"];
                    nameR = Request.Form["nameR"];
                    emailR = Request.Form["emailR"];
                    positionR = Request.Form["positionR"];
                    nameS = Request.Form["nameS"];
                    emailS = Request.Form["emailS"];
                    positionS = Request.Form["positionS"];
                    webLink2 = Request.Form["webLink2"];               
                }
                else
                {
                    result = Request.Form["Result"] + "????" + Request.Form["english"] + "????" + Request.Form["ReceivedInfo"] + "????" + Request.Form["webLink"];
                }
                ViewData["Result"] = result;
                ViewData["check"] = check;
                ViewData["nameR"] = nameR;
                ViewData["namest"] = namest;
                ViewData["nameS"] = nameS;
                ViewData["emailR"] = emailR;
                ViewData["emailst"] = emailst;
                ViewData["emailS"] = emailS;
                ViewData["positionR"] = positionR;
                ViewData["positionst"] = positionst;
                ViewData["positionS"] = positionS;
                ViewData["receivedInfoCourses"] = receivedInfoCourses;
                ViewData["webLink2"] = webLink2;
            }
            catch (Exception)
            {
                ViewData["Result"] = "";
                ViewData["receivedInfoCourses"] = "";
                ViewData["check"] = false;

            }

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult LearningAgreement(string operation)
        {
            try
            {

            
            string result = Request.Form["Result"];
            string namest = Request.Form["namest"];
            string emailst = Request.Form["emailst"];
            string positionst = Request.Form["positionst"];
            string nameR = Request.Form["nameR"];
            string emailR = Request.Form["emailR"];
            string positionR = Request.Form["positionR"];
            string nameS = Request.Form["nameS"];
            string emailS = Request.Form["emailS"];
            string positionS = Request.Form["positionS"];
            string receivedInfoCourses = Request.Form["receivedInfoCourses"];
            string webLink2 = Request.Form["webLink2"];
            var erasmus = result.ToString().Split("????");

            ViewData["namest"] = namest;
            ViewData["emailst"] = emailst;
            ViewData["positionst"] = positionst;
            ViewData["nameR"] = nameR;
            ViewData["emailR"] = emailR;
            ViewData["positionR"] = positionR;
            ViewData["nameS"] = nameS;
            ViewData["positionS"] = positionS;
            ViewData["emailS"] = emailS;
            ViewData["receivedInfoCourses"] = receivedInfoCourses;
            ViewData["webLink2"] = webLink2;
            ViewData["fname"] = erasmus[0];
            ViewData["lname"] = erasmus[1];
            ViewData["birth"] = erasmus[2];
            ViewData["nat"] = erasmus[3];
            ViewData["sex"] = erasmus[4];
            ViewData["sc"] = erasmus[5];
            ViewData["edu"] = erasmus[6];
            ViewData["sin"] = erasmus[7];
            ViewData["sif"] = erasmus[8];
            ViewData["sic"] = erasmus[9];
            ViewData["sia"] = erasmus[10];
            ViewData["sicountry"] = erasmus[11];
            ViewData["sicont"] = erasmus[12];
            ViewData["rif"] = erasmus[13];

            using (var db = new ErasmusContext())
            {
                var instAddress = (
                from Instituition in db.Instituitions
                where Instituition.name.Equals(erasmus[13])
                select Instituition.address);

                ViewData["ria"] = instAddress.First();
            }

            ViewData["dd"] = erasmus[14];
            ViewData["da"] = erasmus[15];
            ViewData["english"] = erasmus[16];
            ViewData["receivedInfo"] = erasmus[17];
            ViewData["webLink"] = erasmus[18];

                List<Course> totalCourses = new List<Course>();
                var received = erasmus[17].Split("++++");
                foreach (string r in received)
                {
                    using (var db = new ErasmusContext())
                    {
                        var c = (
                        from Course in db.Courses
                        where Course.name.Equals(r)
                        select Course);
                        totalCourses.Add(c.First());
                    }
                }
                ViewBag.List = totalCourses;
            }
            catch (Exception)
            {
                ViewBag.List = new List<Course>();
                ViewData["receivedInfoCourses"] = "";
            }
            return View();
        }

        public IActionResult Comment (string operation)
        {
            if(operation != null && operation.Equals("Show Courses"))
            {
                List<Course> instCourses = new List<Course>();
                using (var db = new ErasmusContext())
                {
                    var courses = (
                    from Institution in db.Instituitions
                    where Institution.name.Equals(Request.Form["commentInst"])
                    select Institution.courses);
                   
                    instCourses = courses.First().ToList();
                }                
                ViewBag.List = instCourses;

                ViewData["instName"] = Request.Form["commentInst"];
            }
            else if(operation != null && operation.Equals("Search"))
            {
                List<Course> instCourses = new List<Course>();
                List<Course> coursesByName = new List<Course>();
                using (var db = new ErasmusContext())
                {
                    var courses = (
                    from Institution in db.Instituitions
                    where Institution.name.Equals(Request.Form["commentInst"])
                    select Institution.courses);

                    instCourses = courses.First().ToList();

                    var coursesN = (
                    from Course in instCourses
                    where Course.name.ToLower().Contains(Request.Form["courseName"].ToString().ToLower())
                    select Course);

                    coursesByName = coursesN.ToList();
                    ViewData["CourseName"] = Request.Form["courseName"];
                    ViewData["instName"] = Request.Form["commentInst"];
                }
                ViewBag.List = coursesByName;
            }
            else
            {
                ViewData["instName"] = "Faculty of Architecture";
            }

            return View();
        }

        public IActionResult LoadLearningAgreement(string operation)
        {
            if(operation != null && operation.Equals("Load Learning Agreement"))
            {
                using (var db = new ErasmusContext())
                {
                    var learningAg = (
                    from LearningAgreement in db.LearningAgreements
                    where LearningAgreement.seed.Equals(Request.Form["seed"].ToString())
                    select LearningAgreement.name);

                    if (learningAg.Any())
                    {
                        return new ContentResult()
                        {
                            Content = learningAg.First(),
                            ContentType = "text/html",
                        };
                    }
                    else
                    {
                        return RedirectToAction("FailedLoadSeed");
                    }
                }
            }

            return View();
        }

        public IActionResult CommentCourse(string operation)
        {
            var newComment = false;

            if (operation != null && operation.Equals("Add comment"))
            {
                List<Comment> comments = new List<Comment>();
                newComment = true;
                using (var db = new ErasmusContext())
                {
                    var op = (
                    from Course in db.Courses
                    where Course.name.Equals(Request.Form["courseName"].ToString())
                    select Course.ID);

                    var com = (
                    from Comment in db.Comments
                    where Comment.courseID.Equals(op.First())
                    select Comment);

                    foreach (Comment c in com)
                    {
                        comments.Add(c);
                    }
                }
                ViewBag.List = comments;
                ViewData["CourseName"] = Request.Form["courseName"].ToString();
                ViewData["newComment"] = newComment;
            }
            else if(operation != null && operation.Equals("Submit"))
            {
                List<Comment> comments = new List<Comment>();
                newComment = false;
                using (var db = new ErasmusContext())
                {
                    var op = (
                    from Course in db.Courses
                    where Course.name.Equals(Request.Form["courseName"].ToString())
                    select Course.ID);

                    db.Comments.Add(new Comment { nameUser = Request.Form["authorName"], title = Request.Form["titleName"], text = Request.Form["commentText"], courseID = op.First() });
                    db.SaveChanges();

                    var com = (
                    from Comment in db.Comments
                    where Comment.courseID.Equals(op.First())
                    select Comment);

                    foreach (Comment c in com)
                    {
                        comments.Add(c);
                    }
                }
                ViewBag.List = comments;
                ViewData["CourseName"] = Request.Form["courseName"].ToString();
                ViewData["newComment"] = newComment;
                return RedirectToAction("CommentCourse", new { operation = Request.Form["courseName"].ToString() });
            }
            else if(operation != null)
            {
                List<Comment> comments = new List<Comment>();
                newComment = false;
                using (var db = new ErasmusContext())
                {
                    var op = (
                    from Course in db.Courses
                    where Course.name.Equals(operation)
                    select Course.ID);

                    var com = (
                    from Comment in db.Comments
                    where Comment.courseID.Equals(op.First())
                    select Comment);

                    foreach (Comment c in com)
                    {
                        comments.Add(c);
                    }
                }
                ViewBag.List = comments;
                ViewData["CourseName"] = operation;
                ViewData["newComment"] = newComment;

            }
            else
            {
                List<Comment> comments = new List<Comment>();

                ViewData["newComment"] = newComment;
                ViewBag.List = comments;
            }

            return View();
        }

        public IActionResult SavedLearningAgreement(string operation, string seed)
        {
            if (operation != null && operation.Equals("Save"))
            {
                using (var db = new ErasmusContext())
                {
                    string seedS = "" + Guid.NewGuid().GetHashCode();
                    db.LearningAgreements.Add(new LearningAgreement { seed = seedS , name = Request.Form["fullSavedLA"] });
                    db.SaveChanges();
                    ViewData["seedS"] = seedS;

                    return RedirectToAction("SavedLearningAgreement", new { seed = seedS });
                }
            }
            else
            {
                ViewData["seedS"] = seed;
            }
            return View();
        }

        public IActionResult FailedLoadSeed()
        {
            return View();
        }

    }
}
